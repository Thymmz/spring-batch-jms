package com.walmart.springbatchtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
